# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'ed37401eb0677e3c3e729c6bc3774a43b26c09da043572d8ea256f3ec4b216385c1bbdf334f07157d0caac8896b2cf42bc597325be0c5b91584b6ee765453549'